﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TodoList.Models
{
    public class TodoItemCollection
    {
        public List<TodoItem> AllItems { get; set; }
    }
}