﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoList2.Entities
{
    public class TodoItem
    {
        public string Description { get; set; }
        public DateTime Deadline { get; set; }
    }
}
