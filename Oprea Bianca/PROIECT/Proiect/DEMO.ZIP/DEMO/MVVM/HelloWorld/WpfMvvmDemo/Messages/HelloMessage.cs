﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfMvvmDemo.Messages
{
    class HelloMessage
    {
        public string Text { get; set; }
    }
}
