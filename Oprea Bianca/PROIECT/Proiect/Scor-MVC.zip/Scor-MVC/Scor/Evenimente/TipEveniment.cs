﻿namespace Scor.Evenimente
{
	public enum TipEveniment
	{
		ProgramareMeci,
		StartMeci,
		GolMarcat,
		TerminareMeci
	}
}