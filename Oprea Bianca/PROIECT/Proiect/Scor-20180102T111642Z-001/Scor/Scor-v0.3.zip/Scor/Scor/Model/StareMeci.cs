﻿namespace Scor.Model
{
	public enum StareMeci
	{
		Programat,
		InDesfasurare,
		Terminat
	}
}