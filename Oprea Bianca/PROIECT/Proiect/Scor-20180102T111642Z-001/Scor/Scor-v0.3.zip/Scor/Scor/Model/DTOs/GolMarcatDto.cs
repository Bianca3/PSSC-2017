﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scor.Model.DTOs
{
	public class GolMarcatDto
	{
		//folseste value object pentru Minut
		public byte Minut { get; set; }
		public string NumeEchipa { get; set; }
	}
}
