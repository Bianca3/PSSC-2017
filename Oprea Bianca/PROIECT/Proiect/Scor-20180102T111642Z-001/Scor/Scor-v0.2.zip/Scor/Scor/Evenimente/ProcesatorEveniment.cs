﻿namespace Scor.Evenimente
{
	public abstract class ProcesatorEveniment
	{
		public abstract void Proceseaza(Eveniment e);
	}
}